def lambda_handler(event, context):
    return {"statusCode": 200, "body": "Day5 Lambda deployed via Terraform + CI/CD!"}

